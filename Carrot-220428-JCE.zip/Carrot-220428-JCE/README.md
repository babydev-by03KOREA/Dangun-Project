# clone
JSP로 우리동네 맛집대전 사이트 구현함.
Data분석 후, JSON형태로 파싱됨.
